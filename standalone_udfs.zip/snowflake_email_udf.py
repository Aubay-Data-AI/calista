import re
from snowflake.snowpark.types import BooleanType, StringType
from email_validator import validate_email, EmailNotValidError

EMAIL_REGEX = re.compile(
    r"^(?P<local>[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)@(?P<domain>[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})$"
)

DISPLAY_NAME_REGEX = re.compile(r"^(?P<display>.+?)\s*<(?P<email>.+?)>$")

class EmailSyntaxError(ValueError):
    pass

def split_email(email: str):
    email = email.strip()
    match = DISPLAY_NAME_REGEX.match(email)
    if match:
        display_name = match.group("display").strip()
        email = match.group("email").strip()
    else:
        display_name = None

    if "@" not in email:
        raise EmailSyntaxError("Invalid email format: missing '@'.")

    local_part, domain_part = email.rsplit("@", 1)
    is_quoted_local_part = local_part.startswith('"') and local_part.endswith('"')

    return display_name, local_part, domain_part, is_quoted_local_part

def validate_email_snowflake(email: str) -> bool:
    if not email:
        return False
    email = email.strip()
    try:
        display_name, local_part, domain_part, is_quoted_local_part = split_email(email)
    except EmailSyntaxError:
        return False

    if not EMAIL_REGEX.match(f"{local_part}@{domain_part}"):
        return False
    if not local_part or len(local_part) > 64:
        return False
    if is_quoted_local_part and '"' in local_part[1:-1]:
        return False
    if not domain_part or len(domain_part) > 255:
        return False
    if domain_part.startswith("[") and domain_part.endswith("]"):
        ip_address = domain_part[1:-1]
        if not re.fullmatch(r"(\d{1,3}\.){3}\d{1,3}", ip_address):
            return False
    if len(email) > 320:
        return False
    return True

# Snowflake registration wrapper explicitly clear and standalone
def init_udf_email(session):
    session.sql("USE DATABASE RESSOURCES").collect()
    session.sql("USE SCHEMA TESTS_UNITAIRES").collect()

    session.udf.register(
        validate_email_snowflake,
        name="validate_email",
        input_types=[StringType()],
        return_type=BooleanType(),
        replace=True,
        packages=["email_validator"],  # Explicitly include email_validator
    )

    print("✅ UDF 'validate_email' registered successfully.")
